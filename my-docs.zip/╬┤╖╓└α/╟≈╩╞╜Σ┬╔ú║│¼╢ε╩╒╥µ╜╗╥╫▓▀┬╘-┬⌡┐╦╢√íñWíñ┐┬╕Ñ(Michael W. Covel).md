---
doc_type: weread-highlights-reviews
bookId: CB_6043Ku3OP24R6Sx6UI
author: 迈克尔·W·柯弗(Michael W. Covel)
cover: https://res.weread.qq.com/wrepub/CB_6043Ku3OP24R6Sx6UI_parsecover
reviewCount: 0
noteCount: 1
isbn: 
category: 
lastReadDate: 2021-08-21T00:00:00.000Z
profileName: lusongcai
postId: '89'
categories:
  - 5
---
# 元数据
> [!abstract] 趋势戒律：超额收益交易策略
> - ![ 趋势戒律：超额收益交易策略|200](https://res.weread.qq.com/wrepub/CB_6043Ku3OP24R6Sx6UI_parsecover)
> - 书名： 趋势戒律：超额收益交易策略
> - 作者： 迈克尔·W·柯弗(Michael W. Covel)
> - 简介： 
> - 出版时间 
> - ISBN： 
> - 分类： 
> - 出版社： 人民邮电出版社

# 高亮划线

## 投机


- 📌 1．自主：一个人必须进行独立思考，而不是盲从。相信自己的判断是成功的基础。2．有判断力：对各种力量进行判断，并在它们之间求得平衡对于投机来说是非常重要的。3．勇敢：一旦下了决心就要坚决执行。下面这句格言之于投机很有价值：勇敢，再勇敢些，就这样一直勇敢下去 。 ^CB-6043Ku3OP24R6Sx6UI-11-2015-2194
    - ⏱ 2021-08-21 10:43:43 
# 读书笔记

# 本书评论
